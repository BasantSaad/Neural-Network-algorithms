#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.title("PCA from Scratch - Interactive")

st.write("## Input Data (X, Y) Points")
st.write("Enter your data points below or use the default sample data.")


n_points = st.number_input("Number of points", min_value=3, max_value=100, value=10, step=1)


default_data = pd.DataFrame({
    "X": [1.4, 1.6, -1.4, -2, -3, 2.4, 1.5, 2.3, -3.2, -4.1],
    "Y": [1.65, 1.975, -1.775, -2.525, -3.95, 3.075, 2.025, 2.75, -4.05, -4.85]
})
user_data = st.data_editor(default_data.head(n_points), num_rows="dynamic")


data = user_data.to_numpy()

# PCA Function
def pca_from_scratch(X):
    # Step 1: Compute Mean
    mean_X = np.mean(X, axis=0)
    X_centered = X - mean_X  # Center the data

    # Step 2: Compute Covariance Matrix
    cov_matrix = np.cov(X_centered, rowvar=False)

    # Step 3: Compute Eigenvalues and Eigenvectors
    eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)
    eigenvectors = -eigenvectors
    # Step 4: Sort Eigenvalues and Eigenvectors in Descending Order
    sorted_indices = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[sorted_indices]
    eigenvectors = eigenvectors[:, sorted_indices]

    # Step 5: Transform Data (Project onto Eigenvectors)
    X_transformed = X_centered @ eigenvectors

    return X_transformed, eigenvectors, eigenvalues

# Run PCA
if data.shape[0] > 1:
    transformed_data, eigenvectors, eigenvalues = pca_from_scratch(data)

    # Display Results
    st.write("### 🟢 Covariance Matrix")
    st.write(np.cov(data - np.mean(data, axis=0), rowvar=False))

    st.write("### 🔹 Eigenvalues")
    st.write(eigenvalues)

    st.write("### 🔸 Eigenvectors")
    st.write(eigenvectors)

    # Plot Original and Transformed Data
    fig, ax = plt.subplots(1, 2, figsize=(12, 5))

    # Original Data
    ax[0].scatter(data[:, 0], data[:, 1], color='blue', edgecolors='black', alpha=0.7)
    ax[0].set_title("Original Data")
    ax[0].set_xlabel("X")
    ax[0].set_ylabel("Y")

    # Transformed Data
    ax[1].scatter(transformed_data[:, 0], transformed_data[:, 1], color='red', edgecolors='black', alpha=0.7)
    ax[1].set_title("Transformed Data (PCA)")
    ax[1].set_xlabel("Principal Component 1")
    ax[1].set_ylabel("Principal Component 2")

    st.pyplot(fig)

    # Download Transformed Data
    transformed_df = pd.DataFrame(transformed_data, columns=["PC1", "PC2"])
    st.download_button(label="Download Transformed Data", data=transformed_df.to_csv(index=False), file_name="pca_transformed.csv", mime="text/csv")


# In[ ]:




